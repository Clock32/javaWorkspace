package com.kh.practice.student.run;

import com.kh.practice.student.view.StudentMenu;

public class Run {
public static void main(String[] args) {
	
	StudentMenu sm = new StudentMenu();
	
}
}
